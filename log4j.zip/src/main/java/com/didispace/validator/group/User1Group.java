/**
* 
* @author Mity1299
*/
package com.didispace.validator.group;

/**
 * @author Mity1299
 *
 */
public interface User1Group {

}
