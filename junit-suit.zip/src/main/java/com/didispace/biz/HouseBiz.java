/**
* 
* @author Mity1299
*/
package com.didispace.biz;

import com.didispace.entity.House;

/**
 * @author Mity1299
 *
 */
public interface HouseBiz {

    public void insert(House house);
}
