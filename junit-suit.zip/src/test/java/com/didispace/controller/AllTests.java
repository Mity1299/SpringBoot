/**
* 
* @author Mity1299
*/
package com.didispace.controller;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * @author Mity1299
 *
 */
@RunWith(Suite.class)
@SuiteClasses({ HouseControllerTest.class, UserControllerTest.class })
public class AllTests {

}
